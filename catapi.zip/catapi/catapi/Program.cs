﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace catapi
{
    class Program
    {
        static async Task Main(string[] args)
        {
            using var client = new HttpClient();

            //Build Url and add required headers
            client.BaseAddress = new Uri("https://api.thecatapi.com/v1");
            client.DefaultRequestHeaders.Add("x-api-key", "ed478781-c445-4546-b090-f3d3d747317d");
            var url = "v1/breeds?limit=10";
            // Now get data 
            HttpResponseMessage response = await client.GetAsync(url);
            response.EnsureSuccessStatusCode();
            //read response data
            var resp = await response.Content.ReadAsStringAsync();
            // Deserialize from Json to catdatamodel type
            IEnumerable<Rootobject> r=JsonConvert.DeserializeObject<List<Rootobject>>(resp);
            
            // now iterate through the catdatamodel data from above step
            foreach(var data in r)
            {
                Console.WriteLine(" name- " + data.name);
                Console.WriteLine("Origin-" + data.origin);
                Console.WriteLine("Weight-" + data.weight.metric);
                Console.WriteLine("--------------------------------------------------------------------------------------------------------");

            }
        }
    }

    
    
}

