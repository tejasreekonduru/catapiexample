﻿namespace catapi
{
    internal class Contributor
    {
    }
}